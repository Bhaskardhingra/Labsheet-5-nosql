# Neo4j setup and explanations

## Setup (Q11)
1. Install Neo4j Desktop or Neo4j Server using the official instructions for your OS.
2. Create/start a local DBMS and open Neo4j Browser.
3. Connect with your database credentials.
4. Open `lab_sheet_5.cypher`, run each labeled question section separately, and inspect graph-returning queries.

## Key concepts
- **Node:** an entity such as `Student`, `Course`, `Customer`, or `Product`.
- **Relationship:** a named connection between nodes, such as `ENROLLED_IN` or `PLACED`.
- **Property:** key/value data stored on nodes or relationships.
- **Cypher:** Neo4j's graph query language (`CREATE`, `MATCH`, `SET`, `DELETE`).
- **Transactions:** a group of database operations can be committed together or rolled back together when executed through a transaction-capable client. Neo4j Browser submissions generally execute each submitted statement as a transaction, so use a driver transaction to group multiple statements atomically.
- **Scaling and availability (Q15):** Neo4j supports clustered deployments and replication options depending on edition/version. Relationship queries are a natural fit for social networks, recommendations, fraud detection, and knowledge graphs. Deployment topology and availability are configuration-dependent.

## Q14 caution
The `.cypher` file provides separate operation examples. To demonstrate atomicity for multiple statements, run the corresponding CREATE/SET operations from a Neo4j driver transaction; do not assume several separately submitted Browser statements form one transaction.
