// Neo4j Lab Sheet 5 — Q11–Q15
// Run these sections in Neo4j Browser. Each section is labeled by question.

// Q11. Student, Course, Department graph.
CREATE (s:Student {studentId:'S101', name:'Aarav'})
CREATE (c:Course {courseId:'C01', title:'BCA'})
CREATE (d:Department {departmentId:'D01', name:'Computer Applications'})
CREATE (s)-[:ENROLLED_IN]->(c)
CREATE (c)-[:OFFERED_BY]->(d);
MATCH (s:Student)-[r]->(x)
RETURN s, r, x;

// Q12. Social network: Person with FRIENDS_WITH, FOLLOWS, WORKS_AT.
CREATE (p1:Person {name:'Asha'})
CREATE (p2:Person {name:'Rohan'})
CREATE (p3:Person {name:'Mira'})
CREATE (company:Company {name:'TechWorks'})
CREATE (p1)-[:FRIENDS_WITH]-(p2)
CREATE (p1)-[:FOLLOWS]->(p3)
CREATE (p2)-[:WORKS_AT]->(company);
 // Find Asha's friends:
MATCH (:Person {name:'Asha'})-[:FRIENDS_WITH]-(friend:Person)
RETURN friend;
 // Find people who follow Mira:
MATCH (follower:Person)-[:FOLLOWS]->(:Person {name:'Mira'})
RETURN follower;

// Q13. E-commerce graph: Customer, Product, Category, Order.
CREATE (cust:Customer {customerId:'CU01', name:'Bhaskar'})
CREATE (prod:Product {productId:'P01', name:'Running Shoes', price:2499})
CREATE (cat:Category {name:'Footwear'})
CREATE (ord:Order {orderId:'O01', orderDate:'2026-10-15'})
CREATE (prod)-[:IN_CATEGORY]->(cat)
CREATE (cust)-[:PLACED]->(ord)
CREATE (ord)-[:CONTAINS {quantity:1}]->(prod);
 // Products purchased by a particular customer:
MATCH (:Customer {customerId:'CU01'})-[:PLACED]->(:Order)-[:CONTAINS]->(p:Product)
RETURN p.name AS product, p.price AS price;

// Q14. Transactions, consistency and availability.
// Neo4j Browser executes each submitted statement as a transaction. In applications,
// group related writes inside one explicit driver transaction when needed.
// Example multi-operation transaction (execute as one transaction in a driver):
// BEGIN/COMMIT syntax depends on the client; the Cypher statements below are the operations.
CREATE (c:Customer {customerId:'CU02', name:'Diya'})
CREATE (p:Product {productId:'P02', name:'Notebook', price:80})
CREATE (o:Order {orderId:'O02', status:'created'})
CREATE (c)-[:PLACED]->(o)
CREATE (o)-[:CONTAINS {quantity:2}]->(p);
MATCH (o:Order {orderId:'O02'})
SET o.status = 'paid', o.total = 160;
MATCH (o:Order {orderId:'O02'})
RETURN o;
 // Delete a sample record only when demonstrating deletion:
 // MATCH (o:Order {orderId:'O02'}) DETACH DELETE o;
 // In production, run related operations inside one driver-managed transaction.

// Q15. Small graph application: CRUD and relationship-based queries.
// CREATE
CREATE (p:Person {personId:'P100', name:'Kiran', city:'Haridwar'});
// READ
MATCH (p:Person {personId:'P100'}) RETURN p;
// UPDATE
MATCH (p:Person {personId:'P100'}) SET p.city='Dehradun' RETURN p;
// Relationship-based query / recommendation example:
MATCH (a:Person {personId:'P100'})-[:FRIENDS_WITH]-(friend:Person)-[:LIKES]->(item:Product)
RETURN DISTINCT item.name AS recommendedProduct;
// DELETE (uncomment to run; deletes only the sample node and its relationships):
// MATCH (p:Person {personId:'P100'}) DETACH DELETE p;

// Useful constraints for reliable IDs (run once per database):
CREATE CONSTRAINT student_id IF NOT EXISTS FOR (s:Student) REQUIRE s.studentId IS UNIQUE;
CREATE CONSTRAINT product_id IF NOT EXISTS FOR (p:Product) REQUIRE p.productId IS UNIQUE;
