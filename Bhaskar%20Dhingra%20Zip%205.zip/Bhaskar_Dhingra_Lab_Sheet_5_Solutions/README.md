# BCA305P — NoSQL Database Design Lab Sheet 5
**Prepared for: Bhaskar Dhingra**

This solution pack covers all 15 questions in the supplied lab sheet:
- Questions 1–10: Riak KV
- Questions 11–15: Neo4j / Cypher

## Requirements
- Riak KV node reachable at `http://localhost:8098` with the HTTP API enabled.
- Python 3.10+ and `requests` for the Riak examples: `python -m pip install requests`
- Neo4j Desktop or Neo4j Server, with a database running and Neo4j Browser available.
- Run the `.cypher` scripts in Neo4j Browser. These examples use the default database and standard Cypher syntax.

## Important notes
- Riak KV's availability and exact setup commands differ by release and Linux distribution. Follow the installation instructions for the specific Riak release you install; do not blindly run package commands for a different release.
- The Python examples use Riak's HTTP API at port 8098. Adjust `RIAK_URL` in `riak_examples.py` if your local setup differs.
- Some Riak releases/configurations do not have secondary indexes, CRDT data types, or legacy bucket-property behavior enabled. The solutions demonstrate the intended concepts and include application-level alternatives where needed.
- Neo4j's graph visualizations appear in Neo4j Browser when a query returns nodes and relationships.
