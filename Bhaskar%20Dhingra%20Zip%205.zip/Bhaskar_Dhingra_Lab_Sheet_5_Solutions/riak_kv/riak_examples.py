"""
Riak KV Lab Sheet 5 — Questions 1–10
Run: python -m pip install requests
Then: python riak_examples.py
Assumes a reachable Riak HTTP API at http://localhost:8098.
These are concise, runnable demonstrations; edit the sample data as required.
"""
import json
import requests

RIAK_URL = "http://localhost:8098"
TIMEOUT = 10

def put(bucket, key, value):
    url = f"{RIAK_URL}/buckets/{bucket}/keys/{key}"
    response = requests.put(url, json=value, timeout=TIMEOUT)
    response.raise_for_status()
    print("PUT", bucket, key, response.status_code)

def get(bucket, key):
    url = f"{RIAK_URL}/buckets/{bucket}/keys/{key}"
    response = requests.get(url, timeout=TIMEOUT)
    if response.status_code == 404:
        print("Not found:", bucket, key)
        return None
    response.raise_for_status()
    try:
        return response.json()
    except ValueError:
        return response.text

def delete(bucket, key):
    response = requests.delete(
        f"{RIAK_URL}/buckets/{bucket}/keys/{key}", timeout=TIMEOUT
    )
    if response.status_code not in (204, 404):
        response.raise_for_status()
    print("DELETE", bucket, key, response.status_code)

def show(label, value):
    print(f"\n{label}:\n{json.dumps(value, indent=2, ensure_ascii=False)}")

# Q1. Student records: create/store, retrieve, update, delete.
def q1_students():
    student = {"id": "S101", "name": "Aarav", "course": "BCA", "year": 3}
    put("students", "S101", student)
    show("Q1 retrieved", get("students", "S101"))
    student["year"] = 4
    put("students", "S101", student)
    show("Q1 updated", get("students", "S101"))
    # Uncomment to demonstrate deletion:
    # delete("students", "S101")

# Q2. User sessions keyed by session ID.
def q2_sessions():
    session = {
        "session_id": "sess-001", "user_id": "U101",
        "login_time": "2026-10-15T09:00:00+05:30", "status": "active"
    }
    put("user_sessions", session["session_id"], session)
    show("Q2 session", get("user_sessions", "sess-001"))

# Q3. User profiles and preferences; demonstrate PUT and GET.
def q3_profiles():
    profile = {
        "name": "Bhaskar", "email": "bhaskar@example.com", "city": "Haridwar",
        "language": "English", "theme": "dark",
        "notifications": {"email": True, "push": False}
    }
    put("user_profiles", "U101", profile)
    show("Q3 profile", get("user_profiles", "U101"))

# Q4. Shopping cart: add/update/retrieve/remove a product.
def q4_cart():
    cart = {"user_id": "U101", "items": [
        {"product_id": "P10", "quantity": 2, "price": 199.0}
    ]}
    put("shopping_carts", "U101", cart)  # add
    show("Q4 cart", get("shopping_carts", "U101"))
    cart["items"][0]["quantity"] = 3  # update
    put("shopping_carts", "U101", cart)
    show("Q4 updated cart", get("shopping_carts", "U101"))
    cart["items"] = [i for i in cart["items"] if i["product_id"] != "P10"]  # remove
    put("shopping_carts", "U101", cart)
    show("Q4 cart after removal", get("shopping_carts", "U101"))

# Q5. String, JSON document, and list values; bucket/key/value roles.
def q5_value_types():
    put("value_types", "welcome", {"value": "Hello Riak", "type": "string"})
    put("value_types", "student-json", {"id": "S102", "name": "Diya"})
    put("value_types", "subjects-list", {"value": ["DBMS", "Python", "Java"], "type": "list"})
    show("Q5 string-like value", get("value_types", "welcome"))
    show("Q5 JSON document", get("value_types", "student-json"))
    show("Q5 list-like value", get("value_types", "subjects-list"))
    print("Bucket = collection/namespace; key = unique identifier within bucket; value = stored data.")

# Q6. Demonstrate quorum parameters (R/W) using legacy bucket properties.
# Availability of these properties depends on Riak release/configuration.
def q6_quorums():
    bucket = "consistency_demo"
    props_url = f"{RIAK_URL}/buckets/{bucket}/props"
    props = {"props": {"n_val": 3, "r": 2, "w": 2, "dw": 2}}
    response = requests.put(props_url, json=props, timeout=TIMEOUT)
    print("Q6 set bucket properties:", response.status_code, response.text[:300])
    put(bucket, "record-1", {"value": "quorum example"})
    show("Q6 read", get(bucket, "record-1"))
    print("R=2 and W=2 request responses from two replicas; tune against cluster size and release support.")

# Q7. Multiple buckets and many records; horizontal scaling concept.
def q7_scaling():
    for bucket in ("scale_students", "scale_courses", "scale_events"):
        for i in range(1, 101):
            put(bucket, f"record-{i:03}", {"number": i, "bucket": bucket})
    print("Inserted 300 records in three buckets.")
    print("Riak partitions the keyspace across vnode partitions on cluster nodes; adding nodes can redistribute ownership.")

# Q8. Transaction-like sequence; read-modify-write is not an atomic multi-key transaction.
def q8_transaction_like():
    key = "U202"
    cart = {"items": [], "total": 0.0}
    put("shopping_carts", key, cart)
    cart = get("shopping_carts", key) or {"items": [], "total": 0.0}
    cart["items"].append({"product_id": "P20", "quantity": 1, "price": 50.0})
    put("shopping_carts", key, cart)
    cart = get("shopping_carts", key) or cart
    cart["items"][0]["quantity"] = 2
    cart["total"] = sum(x["quantity"] * x["price"] for x in cart["items"])
    put("shopping_carts", key, cart)
    show("Q8 final cart", get("shopping_carts", key))
    print("Limitation: multiple requests are not one atomic transaction; concurrent writes can conflict.")

# Q9. Query-by-data using application-level filtering (fetch known keys).
# Plain KV does not automatically search arbitrary JSON fields. A production app needs
# a maintained index, a supported search/index feature, or an external query service.
def q9_query_by_data():
    records = [
        ("U301", {"name": "Asha", "city": "Haridwar", "age": 21, "preference": "dark"}),
        ("U302", {"name": "Rohan", "city": "Delhi", "age": 22, "preference": "light"}),
        ("U303", {"name": "Mira", "city": "Haridwar", "age": 20, "preference": "dark"}),
    ]
    for key, value in records:
        put("query_users", key, value)
    # Application-level demonstration over the known keys:
    found = []
    for key, _ in records:
        value = get("query_users", key)
        if value and value.get("city") == "Haridwar":
            found.append({"key": key, **value})
    show("Q9 users in Haridwar", found)

# Q10. Set-like operations represented as JSON lists and application logic.
# This illustrates the operations; JSON read-modify-write is not a CRDT set.
def q10_set_operations():
    interests = {"values": ["basketball", "music", "coding"]}
    put("user_interests", "U401", interests)
    interests = get("user_interests", "U401") or {"values": []}
    if "reading" not in interests["values"]:
        interests["values"].append("reading")   # add
    interests["values"] = [x for x in interests["values"] if x != "music"]  # remove
    put("user_interests", "U401", interests)
    show("Q10 membership: basketball", "basketball" in interests["values"])
    other = {"basketball", "coding", "travel"}
    show("Q10 common interests", sorted(set(interests["values"]) & other))
    show("Q10 final set-like list", interests["values"])

if __name__ == "__main__":
    for function in (
        q1_students, q2_sessions, q3_profiles, q4_cart, q5_value_types,
        q6_quorums, q7_scaling, q8_transaction_like, q9_query_by_data,
        q10_set_operations
    ):
        print("\\n" + "=" * 60, function.__name__)
        try:
            function()
        except requests.RequestException as exc:
            print("HTTP error:", exc)
            print("Check that Riak is running and RIAK_URL is correct.")
