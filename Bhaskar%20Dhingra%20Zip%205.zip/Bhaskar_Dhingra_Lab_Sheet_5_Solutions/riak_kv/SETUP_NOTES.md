# Riak KV setup notes (Question 1)
1. Use the official installation instructions for the Riak KV version supported by your Linux distribution.
2. Start the Riak node using the service/start command documented for that package.
3. Confirm the node is healthy using the release's documented `riak ping` / status command.
4. Confirm the HTTP API is listening at `http://localhost:8098`.
5. Install the Python dependency: `python -m pip install requests`
6. Run `python riak_examples.py`.

Conceptual consistency note (Q6): with a replicated bucket, R and W are quorum-style read/write acknowledgements. Values such as R=2 and W=2 should only be used where supported and sensible for the cluster's replication factor. Quorums trade latency/availability against confidence that multiple replicas responded; they do not make unrelated operations a full transaction.
